import shutil # модуль архиватора/разархиватора

shutil.make_archive('lesson', 'zip')

with open('lesson6.zip', 'rb') as fd:
    print (len(fd.read()))