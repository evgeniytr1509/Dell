message = "hello word"
offset = 26

for i in message:
    print (ord(i))
    print (chr(ord("a")+15))


