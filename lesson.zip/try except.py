
try:
    print (7/0)

except ZeroDivisionError:
    pass# чтоб ничего не делать после ехсерт
    print ("На 0 делить нельзя")
print ("Программа завершена")