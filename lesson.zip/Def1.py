def format_string(string, length):
    
    count = 0
    for i in string:
        count = count + 1
    
    print (count)
    print ("hello")    

    #if count >= length:


format_string("Hello", 12)
        
