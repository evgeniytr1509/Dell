some_string = " Ми вчимо Java?"
result = some_string