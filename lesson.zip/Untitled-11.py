def real_len(text):
    d=len(text)
    print (d)
real_len('Alex\nKdfe23\t\f\v.\r')    