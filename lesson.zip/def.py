def get_fullname (first_name=str ("John"), last_name=str ("Smith"), middle_name=str ("") ):
   
    print (first_name, last_name, middle_name)

get_fullname()