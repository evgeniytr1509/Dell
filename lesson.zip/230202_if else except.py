# sum = 0
# a = 1
# while a <= 5:
# 	sum +=a
# 	a=a+1
# print (sum)

#***************

# print (int (float('12')))
# a= float ('12.5')
# b=int(a)
# print (a,b)

# nums = [1, 2, 3, 5, 6]

# sum = 0
# print(sum(nums))

#**************

nums = [-1, -5, -8, 4, 9]
k=0
for n in nums:
    if k < n:
        k=n
print (k)
