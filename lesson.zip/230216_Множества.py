# множества

set1 = set()

set2 = {1, 2}

set3 = set("qweweqweqw")

print(set3)

set4 = set([(1,2), (3,4)])