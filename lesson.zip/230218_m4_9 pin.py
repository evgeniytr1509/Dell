"""Sets"""
# множества удаляет дубли
my_set1 = set('hello')
my_set2 = {"1112", "333", "544", "333", "5", "5", "7", "8"}
my_set3 = ('helloolo')
my_set4 = set('hesslloolo')
my_set5 = set(range (3,15))
my_set6 = set() # множества
my_set7 = {} # словарь
a = [12, 45, 87, 15, 78, 99, 12, 45]
a = list(set (a))
print (a)


# print(my_set1)
# print(my_set2)
# print(my_set3)
# print(my_set4)
# print(my_set5)
# print(my_set6)
# print(type(my_set1))
# print(type(my_set2))
# print(type(my_set3))
# print(type(my_set4))
# print(type(my_set5))
# print(type(my_set6))
# print(type(my_set7))



# set1 = set('hello')
# set2 = set('aloha')

# print(set1 | set2)

# if len('hello') != len(set('hello')):
#     print('double')
    
# print(set1 ^ set2)

# set1 = set('defdgh')
# set2 = set('defgh')

# set3 = set1 == set2

# print(set3)

# if set3:
#     print('done')
# else:
#     print('none')
