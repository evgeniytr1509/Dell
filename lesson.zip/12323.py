a = ['car', 'top', 'lot']
a.append('row')
print(a)
['car', 'top', 'lot', 'row']