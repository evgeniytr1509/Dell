a = 1, 3, 4
c = 5, 8, 9
b = tuple(a)
print (b, type(b))
print (a)
print (len(a))
print (2 in a)
print (a + c)
print (a*5)
print (min (a))
print (sum(a))
