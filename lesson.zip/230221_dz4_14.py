import sys

def parse_args():
    result = ""
    for arg in sys.argv:
        
        return " ".join(sys.argv[1:])
            
    return result
parse_args("python run.py first second")