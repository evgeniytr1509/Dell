str = "1Hey Tnere"
str1 = (str.lower())
position = str.lower().find("he")
print (position)