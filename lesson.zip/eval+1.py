#print(eval("2*9")) #eval считат строку

data = input(">>>")
exec(data)# запускает код for i in range (100): print ("232323232") 
print ("you win")