#"""argv"""
import sys
in1 = sys.stdin.readline()
print(in1)
sys.exit()
