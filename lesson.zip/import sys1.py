import sys
print (sys.exec_prefix)
print(sys.getwindowsversion())
print(sys.platform)
print(sys.winver)