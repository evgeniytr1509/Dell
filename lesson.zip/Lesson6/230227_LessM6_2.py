lst = [str(i) for i in range(10)]
fd = open('d://test2.txt', 'w')

fd.writelines(lst)
fd.close()

lst = [str(i) for i in range(10)]
fd = open('d://test2.txt', 'w')

fd.writelines(lst)
fd.close()