result = None
operand1 = None
operand2 = None
operator = None
wait_for_number = True
result = input ("rr")

while True:
    if operator == "+":
        result = float (operand + operand)
        print (result)       
    
    else:
        print ("is not '+' or '-' or '/' or '*'. Try again")