# lang = {"Python": 1991, "Java": 1995, "JS": 1995}
# for l in lang:
#     print(l)

# print ("*****1")
# lang = {"Python": 1991, "Java": 1995, "JS": 1995}
# for l in lang.keys():
#     print(l)

print ("*****2")
lang = {"Python": 1991, "Java": 1995, "JS": 1995}
for value in lang.values():
    print(value)

# print ("*****3")
# lang = {"Python": 1991, "Java": 1995, "JS": 1995}
# for l, value in lang.items():
#     print(f"Programming language {l} - released {value}")


