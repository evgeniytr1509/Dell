articles_dict = [{"title": "Endless ocean waters.", "author": "Jhon Stark", "year": 2019},
{"title": "Oceans of other planets are full of silver", "author": "Artur Clark", "year": 2020,},
{"title": "An ocean that cannot be crossed.", "author": "Silver Name","year": 2021,},
{"title": "The ocean that you love.","author": "Golden Gun","year": 2021,}]



for item in articles_dict.items():
    print(item)


# s1 = {"ключ" : "значения", "яблоко" : "яблоня", "груша" : "грушевое дерево", "банан" : "пальма"}
# print (s1)
# print (s1["груша"]) # вывод слова по ключу (грушевое дерево)


# new_dict = []
# for item in articles_dict:
#     if articles_dict.find("title") != 0:
#         new_dict.append(articles_dict.get(item))
            
# print (new_dict)