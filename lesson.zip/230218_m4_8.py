230218_mod4 ex7 coordinati.py
