import time
a = 5
b = 4
print (a+b)
i=0
while True:
    time.sleep(1)
    i = i + 1
    print (i)