import os
path = 'F:\\Dell\Lesson4_12'
#print (f" все файлы{os.listdir(path)}") # вывод всех файлов
print (os.listdir(path))
#for i in os.listdir(path):
    #print (i, type (i), path + '\\' + i)
    #print (f"name: {i}")
    #print (i)
    #print (i, path + '\\' + i)